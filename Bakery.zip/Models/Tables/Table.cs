﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Bakery.Models.Tables.Contracts;
using Bakery.Models.Drinks.Contracts;
using Bakery.Models.BakedFoods.Contracts;
using Bakery.Models.Tables;
using Bakery.Models.Drinks;
using Bakery.Models.BakedFoods;
using Bakery.Utilities.Messages;

namespace Bakery.Models.Tables
{
    public abstract class Table : ITable
    {
        private List<IBakedFood> bakedFoods;
        private List<IDrink> drinks;
        private int capacity;
        private int numberOfPeople;

        public Table(int tableNumber, int capacity, decimal pricePerPerson)
        {
            bakedFoods = new List<IBakedFood>();

            drinks = new List<IDrink>();
        }

        public int TableNumber { get; private set; }

        public int Capacity
        {
            get
            {
                return this.capacity;
            }

            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidTableCapacity);
                }

                this.capacity = value;
            }
        }

        public int NumberOfPeople
        {
            get
            {
                return this.numberOfPeople;
            }

            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidNumberOfPeople);
                }

                this.numberOfPeople = value;
            }
        }       

        public decimal PricePerPerson { get; private set; }
        
        public bool IsReserved { get; private set; }

        decimal Price
        {
            get
            {
                return PricePerPerson * NumberOfPeople;
            }
        }






        void Reserve(int numberOfPeople);

        void OrderFood(IBakedFood food);

        void OrderDrink(IDrink drink);

        decimal GetBill();

        void Clear();

        string GetFreeTableInfo();
    }
}
