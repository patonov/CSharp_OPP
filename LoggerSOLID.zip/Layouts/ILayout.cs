﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LoggerSOLID.Layouts
{
    public interface ILayout
    {

        string Template { get; }
    }
}
