﻿using LoggerSOLID.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace LoggerSOLID.Appenders
{
    public interface IAppender
    {
        void Append(string date, ReportLevel reportLevel, string message);
    }
}
