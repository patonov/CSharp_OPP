﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using LoggerSOLID.Enums;
using LoggerSOLID.Layouts;
using LoggerSOLID.Loggers;

namespace LoggerSOLID.Appenders
{
    public class FileAppender : Appender
    {
        private ILogFile logFile;

        public FileAppender(ILayout layout, ILogFile logFile) : base(layout)
        {
            this.logFile = logFile;
        }

        public override void Append(string date, ReportLevel reportLevel, string message)
        {
            string content = string.Format(this.layout.Template, date, reportLevel, message) + Environment.NewLine;

            this.logFile.Write(content);
        }
    }
}
