﻿using System;
using System.Collections.Generic;
using System.Text;
using LoggerSOLID.Enums;
using LoggerSOLID.Layouts;

namespace LoggerSOLID.Appenders
{
    public class ConsoleAppender : Appender
    {

        public ConsoleAppender(ILayout layout) : base(layout)
        {

        }

        public override void Append(string date, ReportLevel reportLevel, string message)
        {
            string content = string.Format(this.layout.Template, date, reportLevel, message);

            Console.WriteLine(content);
        }
    }
}
