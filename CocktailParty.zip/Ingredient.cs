﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CocktailParty
{
    public class Ingredient
    {
        private int alcohol;

        public Ingredient(string name, int alcohol, int quantity)
        {
            this.Name = name;
            this.Alcohol = alcohol;
            this.Quantity = quantity;        
        }

        public string Name { get; private set; }

        public int Alcohol 
        {
            get => this.alcohol;
            
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException("The alcohol could not be a negative value");
                }
                this.alcohol = value;
            }
            
        }

        public int Quantity { get; private set; }

        public override string ToString()
        {
            return $"Ingredient: {this.Name}" + Environment.NewLine +
                     $"Quantity: {this.Quantity}" + Environment.NewLine +
                     $"Alcohol: {this.Alcohol}";
            

        }
    }
}
