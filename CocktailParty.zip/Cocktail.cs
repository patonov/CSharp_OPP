﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace CocktailParty
{
    public class Cocktail
    {
        private int maxAlcoholLevel; 

        public Cocktail(string name, int capacity, int maxAlcoholLevel)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.MaxAlcoholLevel = maxAlcoholLevel;
            this.Ingredients = new List<Ingredient>();
        }

        public string Name { get; private set; }

        public int Capacity { get; private set; }

        public int MaxAlcoholLevel 
        {
            get => this.maxAlcoholLevel;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException("The max alcohol level could not be a negative value");
                }
                this.maxAlcoholLevel = value;
            }
        }

        public List<Ingredient> Ingredients { get; private set; }

        public void Add(Ingredient ingredient)
        {
            int restAlc = this.MaxAlcoholLevel;

            foreach (Ingredient ing in this.Ingredients)
            {
                restAlc -= ing.Alcohol;
            }

            if (!this.Ingredients.Contains(ingredient))
            {
                if (this.Ingredients.Count < this.Capacity && ingredient.Alcohol <= restAlc)
                {
                    this.Ingredients.Add(ingredient);
                }
            }
        }

        public bool Remove(string name)
        {
            foreach (Ingredient ing in this.Ingredients)
            {
                if (ing.Name == name)
                {
                    this.Ingredients.Remove(ing);
                    return true;
                }
            }
            return false;
        }

        public Ingredient FindIngredient(string name)
        {
            foreach (Ingredient ing in this.Ingredients)
            {
                if (ing.Name == name)
                {
                    return ing;
                }
            }
            return null;
        }

        public Ingredient GetMostAlcoholicIngredient()
        {
            int maxAlc = 0;

            foreach (Ingredient ing in this.Ingredients)
            {
                if (ing.Alcohol > maxAlc)
                {
                    maxAlc = ing.Alcohol;
                }
            }
            return this.Ingredients.Find(x => x.Alcohol == maxAlc);
        }

        public int CurrentAlcoholLevel()
        {
            int levelAlc = 0;

            foreach (Ingredient ing in this.Ingredients)
            {
                levelAlc += ing.Alcohol;
            }
            return levelAlc;
        }

        public string Report()
        {
            string text = $"Cocktail: {this.Name} - Current Alcohol Level: {this.CurrentAlcoholLevel()}" + Environment.NewLine;
            for (int i = 0; i < this.Ingredients.Count; i++)
            {
                text += this.Ingredients[i].ToString();
                text += Environment.NewLine;
            }

            return text;
        }
    }
}
