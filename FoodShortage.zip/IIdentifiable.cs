﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace PersonInfo
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
