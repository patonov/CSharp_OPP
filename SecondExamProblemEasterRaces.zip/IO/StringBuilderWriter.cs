﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using EasterRaces.Core.Contracts;
using EasterRaces.IO;
using EasterRaces.IO.Contracts;
using EasterRaces.Models.Races.Contracts;
using EasterRaces.Models.Races.Entities;
using EasterRaces.Models.Cars.Contracts;
using EasterRaces.Models.Cars.Entities;
using EasterRaces.Models.Drivers.Contracts;
using EasterRaces.Models.Drivers.Entities;
using EasterRaces.Utilities.Messages;
using EasterRaces.Repositories.Contracts;
using EasterRaces.Repositories.Entities;

namespace EasterRaces.IO
{
    public class StringBuilderWriter : IWriter
    {
        private StringBuilder sb;

        public StringBuilderWriter()
        {
            this.sb = new StringBuilder();
        }

        public void WriteLine(string message)
        {
            this.sb.AppendLine(message);
        }

        public void Write(string message)
        {
            this.sb.Append(message);
        }

        public override string ToString()
        {
            return sb.ToString();
        }
    }
}
