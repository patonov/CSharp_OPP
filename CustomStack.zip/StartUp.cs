﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomStack
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            StackOfStrings stack = new StackOfStrings();

            stack.AddRange(new List<string>() { "Pesho", "Gosho", "Vancho"});
            stack.IsEmpty();
        }
    }
}
