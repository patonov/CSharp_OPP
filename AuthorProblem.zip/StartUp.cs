﻿using System;

namespace AuthorProblem
{
    [Author("Az")]

    public class StartUp
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
