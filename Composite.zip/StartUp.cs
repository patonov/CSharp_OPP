﻿using System;

namespace Composite
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SingleGift phone = new SingleGift("phone", 249);
            phone.CalculateTotalPrice();
            Console.WriteLine();

            CompositeGift rootBox = new CompositeGift("RootBox", 0);
            SingleGift truckToy = new SingleGift("Truck", 15);
            SingleGift plainToy = new SingleGift("Plain", 20);
            rootBox.Add(truckToy);
            rootBox.Add(plainToy);

            Console.WriteLine($"Total price of this composite present is: {rootBox.CalculateTotalPrice()}");
        }
    }
}
