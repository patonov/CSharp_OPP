﻿using System;
using System.Globalization;
using System.Threading;

namespace Bakery
{
    using Bakery.Core;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture("en-GB");
            
            
            
            var engine = new Engine();

            engine.Run();
        }
    }
}
