using ExtendedDatabase;
using NUnit.Framework;
using System;


namespace Tests
{
    public class ExtendedDatabaseTests
    {
        private ExtendedDatabase.ExtendedDatabase dbExt;

        [SetUp]
        public void Setup()
        {
            this.dbExt = new ExtendedDatabase.ExtendedDatabase();
        }

        [Test]
        public void Add_ThrowsInvalidOperationException_When_CapacityIsExceeded()
        {
            for (int i = 0; i < 16; i++)
            {
                this.dbExt.Add(new Person(i, $"user{i}"));
            }

            Assert.Throws<InvalidOperationException>(() => this.dbExt.Add(new Person(16, "Putka")));
        }

        [Test]
        public void Add_ThrowsInvalidOperationException_When_UsernameIsUsed()
        {
            this.dbExt.Add(new Person(1, "Putkar"));

            Assert.Throws<InvalidOperationException>(() => this.dbExt.Add(new Person(2, "Putkar")));
        }

        [Test]
        public void Add_ThrowsInvalidOperationException_When_IdIsUsed()
        {
            this.dbExt.Add(new Person(1, "Putkar"));

            Assert.Throws<InvalidOperationException>(() => this.dbExt.Add(new Person(1, "Mashkar")));
        }

        [Test]
        public void Add_IncreaseCountOfUsers_When_OperationIsValid()
        {
            this.dbExt.Add(new Person(1, "Pesho"));
            this.dbExt.Add(new Person(2, "Gosho"));

            Assert.That(this.dbExt.Count, Is.EqualTo(2));
        }

        [Test]
        public void Remove_ThrowsInvalidOperationException_When_CountIsZero()
        {
            Assert.Throws<InvalidOperationException>(() => this.dbExt.Remove());
        }

        [Test]
        public void Remove_RemovesElementFromDatabase_When_OperationIsValid()
        {
            this.dbExt.Add(new Person(1, "Pesho"));
            this.dbExt.Add(new Person(2, "Gosho"));
            this.dbExt.Add(new Person(3, "Pena"));
            this.dbExt.Add(new Person(4, "Yana"));

            this.dbExt.Remove();

            Assert.That(this.dbExt.Count, Is.EqualTo(3));
            Assert.Throws<InvalidOperationException>(() => this.dbExt.FindById(4));
        }

        [Test]
        [TestCase("")]
        [TestCase(null)]
        public void FindByUsername_ThrowsException_When_ArgumentIsNotValid(string username)
        {
            Assert.Throws<ArgumentNullException>(() => this.dbExt.FindByUsername(username));
        }

        [Test]
        public void FindByUsername_ThrowsInvalidOperationException_When_UserDoesNotExist()
        {
            Assert.Throws<InvalidOperationException>(() => this.dbExt.FindByUsername("Percho")); 
        }

        [Test]
        public void FindByUsername_ReturnsPerson_When_PersonReallyExists()
        {
            Person person = new Person(1, "Putko");

            this.dbExt.Add(person);

            Person personReturned = this.dbExt.FindByUsername("Putko");

            Assert.That(person, Is.EqualTo(personReturned));        
        }

        [Test]
        [TestCase(-2)]
        public void FindById_ThrowsArgumentOutOfRangeException_When_IdIsLessThanZero(long userId)
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => this.dbExt.FindById(userId));
        }

        [Test]
        public void FindById_ThrowsInvalidOperationException_When_IdDoesNotExist()
        {
            Assert.Throws<InvalidOperationException>(() => this.dbExt.FindById(33));
        }

        [Test]
        public void FindById_ReturnsPerson_When_PersonReallyExists()
        {
            Person person = new Person(1, "Percho");
            

            this.dbExt.Add(person);
            
            Person returnedPerson = this.dbExt.FindById(1);

            Assert.That(returnedPerson, Is.EqualTo(person));
        }

        [Test]
        public void Ctor_ThrowsArgumentException_When_CapacityIsExceeded()
        {
            Person[] people = new Person[17];

            for (int i = 0; i < 17; i++)
            {
                people[i] = new Person(i, $"User_{i}");
            }
            Assert.Throws<ArgumentException>(() => this.dbExt = new ExtendedDatabase.ExtendedDatabase(people));
        }

        [Test]
        public void Ctor_AddPersonsToTheDatabase_When_OperationIsValid()
        {
            Person[] people = new Person[4];

            for (int i = 0; i < people.Length; i++)
            {
                people[i] = new Person(i, $"User_{i}");
            }
            
            this.dbExt = new ExtendedDatabase.ExtendedDatabase(people);

            Assert.That(this.dbExt.Count, Is.EqualTo(people.Length));

            Person pers = people[3];
            Person controlPerson = this.dbExt.FindById(3);

            Assert.That(pers, Is.EqualTo(controlPerson));
        }
    }
}