﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {

        protected Vehicle(double fuel, double fuelConsumption, double airConditionModifier)
        {
            this.Fuel = fuel;
            this.FuelConsumption = fuelConsumption;
            this.AirConditionModifier = airConditionModifier;
        }

        private double AirConditionModifier { get; set; }

        public double Fuel { get; private set; }

        public double FuelConsumption { get; private set; }

        public void Drive(double distance)
        {
            double fuelNeeded = this.FuelConsumption * distance + distance * this.AirConditionModifier;

            if (fuelNeeded > this.Fuel)
            {
                throw new InvalidOperationException($"{this.GetType().Name} needs refueling");
            }

            this.Fuel -= fuelNeeded;
        }

        public virtual void Refuel(double amount)
        {
            this.Fuel += amount;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name}: {this.Fuel:f2}";
        }
    }
}
