﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace PersonsInfo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            


        }
    }
}
