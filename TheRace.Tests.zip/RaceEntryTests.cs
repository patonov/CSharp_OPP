using System;
using System.Linq;
using NUnit.Framework;
using TheRace;

namespace TheRace.Tests
{
    public class RaceEntryTests
    {
        private RaceEntry raceEntry;

        [SetUp]
        public void Setup()
        {
            this.raceEntry = new RaceEntry();
        }

        [Test]
        public void Counter_IsZeroByOrDefault()
        {
            Assert.That(this.raceEntry.Counter, Is.Zero);
        }

        [Test]
        public void Counter_Increases_WhenAddingDriver()
        {
            this.raceEntry.AddDriver(new UnitDriver("Pesho", new UnitCar("Volga", 1200, 500)));

            Assert.That(this.raceEntry.Counter, Is.EqualTo(1));
        }

        [Test]
        public void AddDriver_ThrowsException_WhenDriverIsNull()
        {
            Assert.Throws<InvalidOperationException>(() => this.raceEntry.AddDriver(null));
        }

        [Test]
        public void AddDriver_ThrowsException_WhenDriverExists()
        {
            var driverName = "Pendel";

            this.raceEntry.AddDriver(new UnitDriver(driverName, new UnitCar("Jiguli", 1300, 750)));

            Assert.Throws<InvalidOperationException>(() => this.raceEntry.AddDriver(new UnitDriver(driverName, new UnitCar("Moskvitsch", 1100, 600))));
        }

        [Test]
        public void AddDriver_ReturnsExpectedResultMessage()
        {
            string drivName = "Choraibeto";

            var resultMessage = this.raceEntry.AddDriver(new UnitDriver(drivName, new UnitCar("Zasz", 300, 100)));

            var expectedResultMessage = $"Driver {drivName} added in race.";

            Assert.That(expectedResultMessage, Is.EqualTo(resultMessage)); 
        }

        [Test]
        [TestCase(0)]
        [TestCase(1)]
        public void CalculateAverageHorsePower_ThrowsException_WhenInsufficientParticipants(int n)
        {
            Assert.Throws<InvalidOperationException>(() => this.raceEntry.CalculateAverageHorsePower());

            this.raceEntry.AddDriver(new UnitDriver("Putio", new UnitCar("Yje", 49, 85)));

            Assert.Throws<InvalidOperationException>(() => this.raceEntry.CalculateAverageHorsePower());
        }

        [Test]
        public void CalculateAverageHorsePower_ReturnsExpectedCalculatedResults()
        {
            int n = 10;
            double exp = 0;

            for (int i = 0; i < n; i++)
            {
                int hp = 49 + i;
                exp += hp;

                this.raceEntry.AddDriver(new UnitDriver($"Putio-{i}", new UnitCar($"Yje-{i}{i}", hp, 85)));
            }
            exp /= n;

            double actual = this.raceEntry.CalculateAverageHorsePower();

            Assert.That(exp, Is.EqualTo(actual));
        }
    }
}