﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prototype
{
    public abstract class SandwichPrototype
    {
        public abstract SandwichPrototype Clone();
    }
}
