﻿using System;

namespace Prototype
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SandwichMenu menu = new SandwichMenu();

            menu["club"] = new Sandwich("bread", "meat", "cheese", "veggies");

            Sandwich clubSandwich = menu["club"].Clone() as Sandwich;



        }
    }
}
