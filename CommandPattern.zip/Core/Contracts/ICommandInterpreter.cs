﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Reflection;
using CommandPattern.Core.Contracts;
using CommandPattern.Core;
using CommandPattern.Commands;

namespace CommandPattern.Core.Contracts
{
    public interface ICommandInterpreter
    {
        string Read(string args);
    }
}
