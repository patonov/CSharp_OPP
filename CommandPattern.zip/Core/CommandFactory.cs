﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Reflection;
using CommandPattern.Core.Contracts;
using CommandPattern.Commands;

namespace CommandPattern.Core
{
    public class CommandFactory : ICommandFactory
    {
        public ICommand CreateCommand(string commandType)
        {
            Type type = Assembly.GetEntryAssembly().GetTypes()
                .FirstOrDefault(t => t.Name.StartsWith(commandType));

            if (type == null)
            {
                throw new ArgumentException($"{commandType} is invalid command type.");
            }
                

            ICommand instance = (ICommand)Activator.CreateInstance(type);

            return instance;
        }
    }
}
