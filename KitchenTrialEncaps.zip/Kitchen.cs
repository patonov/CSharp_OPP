﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KitchenTrialEncaps
{
    public class Kitchen
    {
        private int meat;

        private int garlic;

        public Kitchen()
        {
            meat = 100;
            garlic = 100;
        }

        public bool MeatballsLeft
        {
            get
            {
                return meat >= 10 && garlic >= 3;
            }
        }

        public void OrderMealball()
        {
            if (CookMealball())
            {
                Console.WriteLine("Meatball cooked.");
            }
            else
            {
                Console.WriteLine("Not enough materials.");
            }
        }

        private bool CookMealball()
        {
            Console.WriteLine("Meatball being cooked");

            if (meat < 10 || garlic < 3)
            {
                return false;
            }

            meat -= 10;
            garlic -= 3;

            return true;
        }
    }
}
