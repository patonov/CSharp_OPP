﻿using System;

namespace KitchenTrialEncaps
{
    class Program
    {
        static void Main(string[] args)
        {
            Kitchen kitchen = new Kitchen();

            if (kitchen.MeatballsLeft)
            {
                kitchen.OrderMealball();
            }
        }
    }
}
